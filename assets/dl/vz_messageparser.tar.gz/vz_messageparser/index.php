<?php

include "functions.php";

$vzs = array('schueler', 'studi', 'mein');
$dirfiles = dirFiles();
$boxes = fillBoxes($dirfiles);

	echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"; //shot tags workaround
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<!-- - - - - - - - - - - - - - - - - <html> - - - - - - - - - - - - - - - - -->
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<!-- - - - - - - - - - - - - - - - - <head> - - - - - - - - - - - - - - - - -->
<head>

<link rel="SHORTCUT ICON" href="favicon.ico" />
<link rel="stylesheet" type="text/css" href="style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- - - - - - - - - - - - - - - - - <style> - - - - - - - - - - - - - - - - -->
<style type="text/css">
</style>
<!-- - - - - - - - - - - - - - - - - </style> - - - - - - - - - - - - - - - - -->

</head>
<!-- - - - - - - - - - - - - - - - - </head> - - - - - - - - - - - - - - - - -->


<!-- - - - - - - - - - - - - - - - - <body> - - - - - - - - - - - - - - - - -->
<body>

<div id="contentbox">
<div id="vz_box">
<div id="vz_l">
<?php foreach($vzs as $v) { echo '<p><strong>'.$v.'vz</strong></p>'; } ?>
</div>
<div id="vz_r">
<?php foreach($vzs as $v) { echo '<p>'.($boxes->$v->loaded ? '<a href="?box='.$v.'">'.(count($boxes->$v->inbox)+count($boxes->$v->outbox)).' Messages</a>' : 'no in/outbox files').'</p>'; } ?>
</div>
<div style="clear: both;"></div>

<?php

if($_GET['box'] != "") {
	$vz = $_GET['box'];
	$conversations = getConvs($boxes->$vz);
	echo '<br /><div id="convs"><p><strong>Conversations:</strong> ';
	foreach($conversations as $key => $c) {
		echo ($key ? ', ' : '').'<a href="?box='.$vz.'&amp;con='.urlSave($c).'">'.$c.'</a>';
		}
	echo '</p></div>';

	if($_GET['con'] != "") {
		$sort = ((isset($_GET['sor'])) ? $_GET['sor'] : 'nfi');
		$con = $_GET['con'];
		$c_msgs = getConvMsgs($boxes->$vz, $con);
		$cdi = getConvDateInfo($c_msgs);
		$c_dates = $cdi[0];
		$c_dates_lo = $cdi[1];
		$c_dates_hi = $cdi[2];
		$from = ((isset($_GET['from'])) ? $_GET['from'] : $c_dates_lo);
		$to = ((isset($_GET['to'])) ? $_GET['to'] : $c_dates_hi);
		$f_msgs = msgDateFilter($c_msgs, $from, $to);

		echo '<form id="settings" action="" method="get">'.
				'<input type="hidden" name="box" value="'.$vz.'" />'.
				'<input type="hidden" name="con" value="'.$con.'" />'.
				'<p>sort: '.
				'<select name="sor" onchange="this.form.submit()">'.
					selectOption('nfi', $sort, 'newer first').
					selectOption('ofi', $sort, 'older first').
				'</select>'.
				'&emsp;show only from: '.
				'<select name="from" onchange="this.form.submit()">';
		usort($c_dates, 'dateSortOfi');
		foreach($c_dates as $d) echo selectOption(compDate($d), $from, $d);
		echo		'</select>'.
				' to: '.
				'<select name="to" onchange="this.form.submit()">';
		usort($c_dates, 'dateSortNfi');
		foreach($c_dates as $d) echo selectOption(compDate($d), $to, $d);
		echo		'</select>'.
				'&emsp;&emsp;('.count($f_msgs).' messages)</p>'.
			'</form>';

		usort($f_msgs, 'msgSort'.$sort);
		drawMessages($f_msgs);
		}
	}

?>

</div>

</body>
<!-- - - - - - - - - - - - - - - - - </body> - - - - - - - - - - - - - - - - -->

</html>
<!-- - - - - - - - - - - - - - - - - </html> - - - - - - - - - - - - - - - - -->
